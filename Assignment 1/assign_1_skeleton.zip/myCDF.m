function output = myCDF(image)

output=zeros(256,1);

% todo

end
